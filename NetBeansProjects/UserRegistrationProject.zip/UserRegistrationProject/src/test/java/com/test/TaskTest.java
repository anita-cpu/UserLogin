package com.test;

import com.Login.RegistrationSystem;
import com.Login.Task;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class TaskTest {

    @Test
    public void testCheckTaskDescriptionSuccess() {
        Task task = new Task("Login Feature", 0, "Create Login to authenticate users", "Robyn Harrison", 8, "TO DO");
        assertTrue(task.checkTaskDescription());
    }

    @Test
    public void testCheckTaskDescriptionFailure() {
        Task task = new Task("Login Feature", 0, "This description is definitely more than fifty characters long and should fail", "Robyn Harrison", 8, "TO DO");
        assertTrue(!task.checkTaskDescription());
    }

    @Test
    public void testCreateTaskID() {
        Task task = new Task("Login Feature", 0, "Create Login to authenticate users", "Robyn Harrison", 8, "TO DO");
        assertEquals("LO:0:SON", task.createTaskID());
    }

    @Test
    public void testPrintTaskDetails() {
        Task task = new Task("Login Feature", 0, "Create Login to authenticate users", "Robyn Harrison", 8, "TO DO");
        String expected = "Task Status: TO DO\n" +
                "Developer Details: Robyn Harrison\n" +
                "Task Number: 0\n" +
                "Task Name: Login Feature\n" +
                "Task Description: Create Login to authenticate users\n" +
                "Task ID: LO:0:SON\n" +
                "Duration: 8 hours";
        assertEquals(expected, task.printTaskDetails());
    }

    @Test
    public void testTotalTaskDuration() {
        RegistrationSystem.tasks.clear();
        RegistrationSystem.totalDuration = 0;

        Task task1 = new Task("Login Feature", 0, "Create Login to authenticate users", "Robyn Harrison", 8, "TO DO");
        Task task2 = new Task("Add Task Feature", 1, "Create Add Task feature to add task users", "Mike Smith", 10, "Doing");

        RegistrationSystem.tasks.add(task1);
        RegistrationSystem.tasks.add(task2);

        int totalDuration = RegistrationSystem.tasks.stream().mapToInt(Task::getTaskDuration).sum();
        assertEquals(18, totalDuration);
    }
}
