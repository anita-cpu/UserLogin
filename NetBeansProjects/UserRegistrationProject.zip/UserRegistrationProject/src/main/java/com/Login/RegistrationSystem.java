package com.Login;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegistrationSystem {
    private static Map<String, User> users = new HashMap<>();
    private static JFrame frame;
    private static JPanel panel;
    private static JTextField usernameField;
    private static JPasswordField passwordField;
    private static JTextField firstNameField;
    private static JTextField lastNameField;
    private static User loggedInUser = null;

    public static List<Task> tasks = new ArrayList<>();
    public static int totalDuration = 0;

    public static void main(String[] args) {
        createAndShowGUI();
    }

    public static void createAndShowGUI() {
        frame = new JFrame("User Registration/Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel(new GridLayout(7, 2));

        panel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        panel.add(usernameField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        panel.add(new JLabel("First Name:"));
        firstNameField = new JTextField();
        panel.add(firstNameField);
        firstNameField.setVisible(true);

        panel.add(new JLabel("Last Name:"));
        lastNameField = new JTextField();
        panel.add(lastNameField);
        lastNameField.setVisible(true);

        JButton actionButton = new JButton("Register");
        actionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (actionButton.getText().equals("Register")) {
                    registerUser();
                } else {
                    loginUser();
                }
            }
        });
        panel.add(actionButton);

        JButton toggleButton = new JButton("Switch to Login");
        toggleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (toggleButton.getText().equals("Switch to Login")) {
                    actionButton.setText("Login");
                    toggleButton.setText("Switch to Registration");
                    firstNameField.setVisible(false);
                    lastNameField.setVisible(false);
                } else {
                    actionButton.setText("Register");
                    toggleButton.setText("Switch to Login");
                    firstNameField.setVisible(true);
                    lastNameField.setVisible(true);
                }
            }
        });
        panel.add(toggleButton);

        frame.getContentPane().add(panel);
        frame.pack();
        frame.setVisible(true);
    }

    public static void registerUser() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();

        if (!checkUserName(username)) {
            JOptionPane.showMessageDialog(frame, "Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return;
        }

        if (!checkPasswordComplexity(password)) {
            JOptionPane.showMessageDialog(frame, "Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
            return;
        }

        User newUser = new User(username, password, firstName, lastName);
        users.put(username, newUser);
        JOptionPane.showMessageDialog(frame, "Registration successful!\nUsername successfully captured.\nPassword successfully captured.");
    }

    public static void loginUser() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (users.containsKey(username)) {
            User user = users.get(username);
            if (user.getPassword().equals(password)) {
                loggedInUser = user;
                JOptionPane.showMessageDialog(frame, "Welcome " + user.getFirstName() + ", " + user.getLastName() + ". It is great to see you again.");
                showMainMenu();
            } else {
                JOptionPane.showMessageDialog(frame, "Password incorrect. Please try again.");
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Username incorrect. Please try again.");
        }
    }

    public static boolean checkUserName(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    public static boolean checkPasswordComplexity(String password) {
        String pattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(password);
        return m.matches();
    }

    public static void showMainMenu() {
        frame.getContentPane().removeAll();
        panel = new JPanel(new GridLayout(5, 1));  // Changed to 5 rows to include the Show Tasks button
        JLabel welcomeLabel = new JLabel("Welcome to EasyKanban");
        panel.add(welcomeLabel);

        JButton addTasksButton = new JButton("1) Add tasks");
        addTasksButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addTasks();
            }
        });
        panel.add(addTasksButton);

        JButton showTasksButton = new JButton("2) Show tasks");  // New button for showing tasks
        showTasksButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showTasks();
            }
        });
        panel.add(showTasksButton);

        JButton showReportButton = new JButton("3) Show report");
        showReportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Coming Soon");
            }
        });
        panel.add(showReportButton);

        JButton quitButton = new JButton("4) Quit");
        quitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
        panel.add(quitButton);

        frame.getContentPane().add(panel);
        frame.pack();
        frame.setVisible(true);
    }

    public static void addTasks() {
        String taskCountStr = JOptionPane.showInputDialog("How many tasks would you like to enter?");
        int taskCount = Integer.parseInt(taskCountStr);

        for (int i = 0; i < taskCount; i++) {
            String taskName = JOptionPane.showInputDialog("Enter task name:");
            String taskDescription = JOptionPane.showInputDialog("Enter task description (max 50 characters):");

            if (taskDescription.length() > 50) {
                JOptionPane.showMessageDialog(frame, "Please enter a task description of less than 50 characters");
                i--;  // Redo this task entry
                continue;
            }

            String developerDetails = JOptionPane.showInputDialog("Enter developer details:");
            String taskDurationStr = JOptionPane.showInputDialog("Enter task duration (in hours):");
            int taskDuration = Integer.parseInt(taskDurationStr);

            String[] taskStatusOptions = {"To Do", "Doing", "Done"};
            String taskStatus = (String) JOptionPane.showInputDialog(frame, "Select task status:", "Task Status",
                    JOptionPane.QUESTION_MESSAGE, null, taskStatusOptions, taskStatusOptions[0]);

            Task newTask = new Task(taskName, tasks.size(), taskDescription, developerDetails, taskDuration, taskStatus);
            tasks.add(newTask);
            totalDuration += taskDuration;
            JOptionPane.showMessageDialog(frame, newTask.printTaskDetails());
        }

        JOptionPane.showMessageDialog(frame, "Total Task Duration: " + totalDuration + " hours");
    }

    public static void showTasks() {
        StringBuilder allTasks = new StringBuilder();
        for (Task task : tasks) {
            allTasks.append(task.printTaskDetails()).append("\n\n");
        }
        JOptionPane.showMessageDialog(frame, allTasks.toString());
    }
}
